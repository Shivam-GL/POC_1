package TESTNG_TESTS;

import java.util.ArrayList;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import Base_Classes.Test_functions;
import UTILITIES.Excel_io;

public class Testing extends Test_functions{
	ArrayList<Test_functions> arrlist;
	int i=0;

  @BeforeClass
  public void read_Test_data() {
	  Excel_io ex=new Excel_io();
	  arrlist=ex.read_excel();
  }
	
  @Test(dataProvider="registerprovider")
  public void Test_case1(String fullname) {
	  launch_chrome();
	  clickSignin();
	  register_user(arrlist,i);
	  
	  arrlist.get(i).actual_val=get_profile();
	  SoftAssert sa=new SoftAssert();
	  System.out.println(fullname);
	  
	  sa.assertEquals(arrlist.get(i).actual_val, fullname);
	  log.info("expected result: "+arrlist.get(i).expected_val+" Actual value: "+arrlist.get(i).actual_val);
	  sa.assertAll();
	  i++;
  }
  @DataProvider(name="registerprovider")
  public String[] get_testdata(){
	  String[] register_name = new String[arrlist.size()];
	  int i=0;
	 for(Test_functions t:arrlist) 
	 {
		 register_name[i]= t.expected_val; 
		 System.out.println(register_name[i]);
		 i++;
	 }
	 
	  return register_name;
  }
  
  @AfterMethod
  public void AM() {
	  dr.close();
  }
  
}
