package UTILITIES;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import Base_Classes.Test_functions;


public class Excel_io {
	File f;
	FileInputStream fis;
	XSSFWorkbook wb;
	static XSSFSheet sh;
	static int no_of_rows;
	
	
	public Excel_io() {
		try {
			this.f=new File("C:\\Users\\shivam.pokhriyal\\Documents\\7.xlsx");
			this.fis=new FileInputStream(f);
			this.wb=new XSSFWorkbook(fis);
			sh=wb.getSheet("Sheet1");
			no_of_rows=count_row();
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	public int count_row() {
		return (sh.getLastRowNum()-sh.getFirstRowNum());	
	}
	
	public ArrayList<Test_functions> read_excel() {
		ArrayList<Test_functions> we=new ArrayList<Test_functions>();
		
		for(int i=1;i<=no_of_rows;i++) {
			Test_functions t1=new Test_functions();
				XSSFRow row=sh.getRow(i);
				XSSFCell cell=row.getCell(1);
				t1.fname=cell.getStringCellValue();
				cell=row.getCell(2);
				t1.lname=cell.getStringCellValue();
				cell=row.getCell(3);
				t1.email=cell.getStringCellValue();
				cell=row.getCell(4);
				t1.pwd=cell.getStringCellValue();
				cell=row.getCell(5);
				t1.address=cell.getStringCellValue();
				cell=row.getCell(6);
				t1.city=cell.getStringCellValue();
				cell=row.getCell(7);
				t1.state=cell.getStringCellValue();
				cell=row.getCell(8);
				t1.zip_code=(int) cell.getNumericCellValue();
				cell=row.getCell(9);
				t1.country=cell.getStringCellValue();
				cell=row.getCell(10);
				t1.mobile=(long) cell.getNumericCellValue();
				System.out.println(t1.mobile);
				cell=row.getCell(11);
				t1.address_alias=cell.getStringCellValue();
				cell=row.getCell(12);
				t1.expected_val=cell.getStringCellValue();
				we.add(t1);
			}
		return we;
	}
	
}
