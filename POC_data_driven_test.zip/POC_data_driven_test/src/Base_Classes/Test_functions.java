package Base_Classes;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Test_functions {
 public  WebDriver dr;
 public Logger log;
 public String fname,lname,email,pwd,address,city,state,country,address_alias,expected_val,actual_val,test_result;
 public long mobile;
 public int zip_code;
 
 public void launch_chrome() {
	 System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		this.dr=new ChromeDriver();
		dr.get("http://automationpractice.com/index.php");
		this.log=Logger.getLogger("devpinoyLogger");
		log.info("launch_chrome invoked");
 }
 public void clickSignin() {
	 log.info("clickSignin invoked");
		 dr.findElement(By.xpath("//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a")).click();
		 log.info("Signin button clicked");
	}
  
 public void register_user(ArrayList<Test_functions>arrlist,int i) {
	 	log.info("register_user invoked");
		dr.findElement(By.xpath("//input[@id=\"email_create\"]")).sendKeys(arrlist.get(i).email);
		dr.findElement(By.xpath("//button[@id=\"SubmitCreate\"]")).click();
		log.info("email id entered");
	 	dr.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
	 	dr.findElement(By.xpath("//input[@id=\"customer_firstname\"]")).sendKeys(arrlist.get(i).fname);
		dr.findElement(By.xpath("//input[@id=\"customer_lastname\"]")).sendKeys(arrlist.get(i).lname);
		dr.findElement(By.xpath("//input[@id=\"passwd\"]")).sendKeys(arrlist.get(i).pwd);
		dr.findElement(By.xpath("//input[@id=\"address1\"]")).sendKeys(arrlist.get(i).address);
		dr.findElement(By.xpath("//input[@id=\"city\"]")).sendKeys(arrlist.get(i).city);
		WebElement we= dr.findElement(By.xpath("//select[@id=\"id_state\"]"));
		Select  sel1=new Select(we);
		sel1.selectByVisibleText(arrlist.get(i).state);
		String Zip_code=String.valueOf(arrlist.get(i).zip_code);
		dr.findElement(By.xpath("//input[@id=\"postcode\"]")).sendKeys(Zip_code);
		we= dr.findElement(By.xpath("//select[@id=\"id_country\"]"));
		sel1=new Select(we);
		sel1.selectByVisibleText(arrlist.get(i).country);
		String Mobile=String.valueOf(arrlist.get(i).mobile);
		dr.findElement(By.xpath("//input[@id=\"phone_mobile\"]")).sendKeys(Mobile);
		dr.findElement(By.xpath("//input[@id=\"alias\"]")).sendKeys(arrlist.get(i).address_alias);
		dr.findElement(By.xpath("//button[@id=\"submitAccount\"]")).click();
		log.info("user registered");
		
 }
 
public String get_profile() {
	WebDriverWait wt=new WebDriverWait(dr,10);
	wt.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@title=\"View my customer account\"]")));
	String profile=dr.findElement(By.xpath("//a[@title=\"View my customer account\"]")).getText();
	return profile;
}
}
